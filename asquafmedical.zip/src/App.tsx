/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Store, 
  Settings as SettingsIcon, 
  Phone, 
  MessageCircle, 
  CheckCircle2, 
  Plus, 
  X,
  Languages,
  Trash2,
  Bell,
  Clock,
  ArrowRight,
  MoreVertical
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, isToday, isPast, isBefore, addDays, parseISO, differenceInDays } from 'date-fns';
import { 
  AppRecord, 
  CustomerRecord, 
  SupplierRecord, 
  AppSettings, 
  TRANSLATIONS, 
  Language, 
  cn 
} from './types';

export default function App() {
  // State
  const [activeTab, setActiveTab] = useState<'customers' | 'suppliers' | 'settings'>('customers');
  const [records, setRecords] = useState<AppRecord[]>(() => {
    const saved = localStorage.getItem('pharmacy_records');
    return saved ? JSON.parse(saved) : [];
  });
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('pharmacy_settings');
    return saved ? JSON.parse(saved) : {
      pharmacyName: 'AsquafMedical',
      reminderTime: '09:00',
      language: 'en'
    };
  });
  const [isAdding, setIsAdding] = useState(false);
  const [notifiedRecords, setNotifiedRecords] = useState<string[]>([]);

  const t = TRANSLATIONS[settings.language];
  const isUrdu = settings.language === 'ur';

  // Persistence
  useEffect(() => {
    localStorage.setItem('pharmacy_records', JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem('pharmacy_settings', JSON.stringify(settings));
  }, [settings]);

  // Notifications logic
  useEffect(() => {
    if (!("Notification" in window)) return;
    
    Notification.requestPermission();

    const checkDueDates = () => {
      const today = new Date();
      records.forEach(record => {
        if (record.status === 'paid') return;
        
        const dueDate = parseISO(record.dueDate);
        const alreadyNotified = notifiedRecords.includes(record.id);

        if (isToday(dueDate) && !alreadyNotified) {
          new Notification(settings.pharmacyName, {
            body: `${isUrdu ? 'آج واجب الادا' : 'Due today'}: ${record.type === 'customer' ? (record as CustomerRecord).customerName : (record as SupplierRecord).supplierName} - Rs. ${record.amount}`,
            icon: '/favicon.ico'
          });
          setNotifiedRecords(prev => [...prev, record.id]);
        }
      });
    };

    const interval = setInterval(checkDueDates, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [records, settings, notifiedRecords, isUrdu]);

  // Actions
  const addRecord = (newRecord: Omit<AppRecord, 'id' | 'status'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    const dueDate = parseISO(newRecord.dueDate);
    let status: AppRecord['status'] = 'pending';
    
    if (isToday(dueDate)) status = 'due-today';
    else if (isPast(dueDate)) status = 'overdue';

    setRecords(prev => [{ ...newRecord, id, status } as AppRecord, ...prev]);
    setIsAdding(false);
  };

  const markAsPaid = (id: string) => {
    setRecords(prev => prev.map(r => r.id === id ? { ...r, status: 'paid' as const } : r));
  };

  const deleteRecord = (id: string) => {
    if (confirm('Delete this record?')) {
      setRecords(prev => prev.filter(r => r.id !== id));
    }
  };

  const toggleLanguage = () => {
    setSettings(prev => ({ ...prev, language: prev.language === 'en' ? 'ur' : 'en' }));
  };

  // View records filter
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (activeTab === 'customers') return r.type === 'customer';
      if (activeTab === 'suppliers') return r.type === 'supplier';
      return false;
    });
  }, [records, activeTab]);

  return (
    <div className={cn(
      "min-h-screen bg-[#0b141a] text-[#e9edef] flex flex-col font-sans",
      isUrdu && "rtl font-medium"
    )} dir={isUrdu ? 'rtl' : 'ltr'}>
      
      {/* Header */}
      <header className="bg-[#202c33] text-[#e9edef] px-4 py-3 shadow-md flex items-center justify-between sticky top-0 z-50 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#00a884] rounded-full flex items-center justify-center text-white">
            <Store size={22} />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">{settings.pharmacyName}</h1>
            <p className="text-[10px] text-[#8696a0] font-medium uppercase tracking-wider">{t.appName}</p>
          </div>
        </div>
        <button 
          onClick={toggleLanguage}
          className="flex items-center gap-2 bg-[#2a3942] px-3 py-1.5 rounded-full text-xs hover:bg-[#3b4a54] transition-colors border border-white/5"
        >
          <Languages size={14} />
          <span>{settings.language === 'en' ? 'اردو' : 'English'}</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto px-4 py-4 mb-20 space-y-5 scroll-smooth">
        {activeTab !== 'settings' && (
          <AnimatePresence mode="popLayout">
            {filteredRecords.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-24 text-[#8696a0]"
              >
                <div className="bg-[#202c33] p-8 rounded-3xl inline-block shadow-lg border border-white/5">
                  <MessageCircle size={56} className="mx-auto mb-5 text-[#00a884]/40" />
                  <p className="text-sm font-medium">{t.noRecords}</p>
                </div>
              </motion.div>
            ) : (
              filteredRecords.map((record) => (
                <RecordBubble 
                  key={record.id} 
                  record={record} 
                  settings={settings}
                  onMarkPaid={markAsPaid}
                  onDelete={deleteRecord}
                />
              ))
            )}
          </AnimatePresence>
        )}

        {activeTab === 'settings' && (
          <SettingsPanel settings={settings} setSettings={setSettings} t={t} records={records} setRecords={setRecords} />
        )}
      </main>

      {/* Input Overlay */}
      <AnimatePresence>
        {isAdding && (
          <AddRecordModal 
            onClose={() => setIsAdding(false)} 
            onAdd={addRecord} 
            activeTab={activeTab} 
            t={t}
            isUrdu={isUrdu}
          />
        )}
      </AnimatePresence>

      {/* Bottom Nav */}
      <nav className="bg-[#202c33] border-t border-white/5 fixed bottom-0 left-0 right-0 h-16 flex items-center justify-around z-40 shadow-[0_-4px_20px_rgba(0,0,0,0.4)]">
        <NavButton 
          active={activeTab === 'customers'} 
          onClick={() => setActiveTab('customers')} 
          icon={<Users size={22} />} 
          label={t.customers}
        />
        <NavButton 
          active={activeTab === 'suppliers'} 
          onClick={() => setActiveTab('suppliers')} 
          icon={<Store size={22} />} 
          label={t.suppliers}
        />
        <NavButton 
          active={activeTab === 'settings'} 
          onClick={() => setActiveTab('settings')} 
          icon={<SettingsIcon size={22} />} 
          label={t.settings}
        />

        {activeTab !== 'settings' && (
          <button 
            onClick={() => setIsAdding(true)}
            className="absolute -top-10 right-6 w-16 h-16 bg-[#00a884] text-white rounded-full flex items-center justify-center shadow-[0_8px_20px_rgba(0,168,132,0.4)] hover:scale-105 active:scale-95 transition-all duration-200 z-50 ring-4 ring-[#202c33]"
          >
            <Plus size={34} />
          </button>
        )}
      </nav>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center flex-1 transition-all duration-200 relative",
        active ? "text-[#00a884]" : "text-[#8696a0]"
      )}
    >
      <motion.div
        animate={{ y: active ? -2 : 0, scale: active ? 1.1 : 1 }}
        className="mb-1"
      >
        {icon}
      </motion.div>
      <span className={cn("text-[10px] font-bold tracking-wide uppercase", active ? "opacity-100" : "opacity-60")}>
        {label}
      </span>
      {active && (
        <motion.div 
          layoutId="navTab"
          className="absolute -top-3 w-8 h-1 bg-[#00a884] rounded-full"
        />
      )}
    </button>
  );
}

function RecordBubble({ 
  record, 
  settings, 
  onMarkPaid,
  onDelete 
}: { 
  record: AppRecord, 
  settings: AppSettings, 
  onMarkPaid: (id: string) => void,
  onDelete: (id: string) => void
}) {
  const [showOptions, setShowOptions] = useState(false);
  const t = TRANSLATIONS[settings.language];
  const isUrdu = settings.language === 'ur';

  const getStatusColor = () => {
    if (record.status === 'paid') return 'bg-[#111b21] text-[#8696a0] border-white/5';
    
    const dueDate = parseISO(record.dueDate);
    if (isToday(dueDate)) return 'bg-[#5c4b00] text-[#fecb00] border-white/10';
    if (isPast(dueDate)) return 'bg-[#4b1c1c] text-[#ff6a6a] border-white/10';
    return 'bg-[#005c4b] text-[#00a884] border-white/10';
  };

  const getDaysInfo = () => {
    if (record.status === 'paid') return null;
    const today = new Date();
    const dueDate = parseISO(record.dueDate);
    const diff = differenceInDays(dueDate, today);
    
    if (diff === 0) return t.dueToday;
    if (diff < 0) return `${Math.abs(diff)} ${t.daysOverdue}`;
    return `${diff} ${t.daysLeft}`;
  };

  const handleCall = () => {
    if (record.type === 'customer') {
      window.location.href = `tel:${record.phoneNumber}`;
    }
  };

  const handleWhatsApp = () => {
    if (record.type === 'customer') {
      const msg = t.whatsappTemplate(record.customerName, settings.pharmacyName, record.amount);
      window.open(`https://wa.me/${record.phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(msg)}`);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className={cn(
        "max-w-[88%] p-3.5 rounded-2xl shadow-md border border-white/5 relative group",
        record.type === 'customer' ? "ml-auto bg-[#005c4b] rounded-tr-none" : "mr-auto bg-[#202c33] rounded-tl-none",
        record.status === 'paid' && "opacity-60 bg-[#111b21] border-white/5"
      )}
    >
      <div className="flex justify-between items-start mb-2 gap-4">
        <div>
          <h3 className={cn("font-bold text-sm", record.type === 'customer' ? "text-[#e9edef]" : "text-[#00a884]")}>
            {record.type === 'customer' ? record.customerName : record.supplierName}
          </h3>
          {record.type === 'customer' && (
            <p className="text-[10px] text-[#8696a0] font-mono mt-0.5 tracking-tight">{record.phoneNumber}</p>
          )}
        </div>
        <div className="flex items-start gap-2">
          <div className="text-right">
            <p className="font-bold text-base text-[#e9edef]">Rs. {record.amount.toLocaleString()}</p>
          </div>
          <div className="relative">
            <button 
              onClick={() => setShowOptions(!showOptions)}
              className="p-1 text-[#8696a0] hover:text-[#e9edef] transition-colors"
            >
              <MoreVertical size={18} />
            </button>
            <AnimatePresence>
              {showOptions && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowOptions(false)} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9, y: -10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: -10 }}
                    className="absolute right-0 top-full mt-1 bg-[#2a3942] border border-white/10 rounded-xl py-1 shadow-xl z-20 min-w-[120px]"
                  >
                    <button 
                      onClick={() => { onDelete(record.id); setShowOptions(false); }}
                      className="w-full text-left px-4 py-2 text-xs text-red-400 hover:bg-white/5 flex items-center gap-2"
                    >
                      <Trash2 size={14} />
                      {settings.language === 'ur' ? 'حذف کریں' : 'Delete'}
                    </button>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <p className="text-xs text-[#d1d7db] mb-3 leading-relaxed">{record.description}</p>

      <div className="flex flex-wrap gap-2 text-[9px] mb-4">
        <div className="bg-black/20 px-2 py-1 rounded flex items-center gap-1.5 border border-white/5">
          <Clock size={10} className="text-[#8696a0]" />
          <span className="text-[#8696a0]">{format(parseISO(record.date), 'dd MMM')}</span>
        </div>
        <div className="bg-black/20 px-2 py-1 rounded flex items-center gap-1.5 border border-white/5">
          <Bell size={10} className="text-[#8696a0]" />
          <span className="text-[#8696a0]">{format(parseISO(record.dueDate), 'dd MMM')}</span>
        </div>
        {getDaysInfo() && (
          <span className={cn("px-2 py-1 rounded border font-bold uppercase tracking-wider", getStatusColor())}>
            {getDaysInfo()}
          </span>
        )}
      </div>

      <div className="flex items-center justify-between mt-1 pt-2.5 border-t border-white/5">
        <div className="flex gap-2">
          {record.status !== 'paid' && record.type === 'customer' && (
            <>
              <button 
                onClick={handleCall}
                className="w-9 h-9 rounded-full bg-[#2a3942] flex items-center justify-center text-[#e9edef] hover:bg-[#3b4a54] transition-colors border border-white/5 active:scale-90"
              >
                <Phone size={14} />
              </button>
              <button 
                onClick={handleWhatsApp}
                className="w-9 h-9 rounded-full bg-[#2a3942] flex items-center justify-center text-[#00a884] hover:bg-[#3b4a54] transition-colors border border-white/5 active:scale-90"
              >
                <MessageCircle size={14} />
              </button>
            </>
          )}
        </div>
        
        {record.status !== 'paid' ? (
          <button 
            onClick={() => onMarkPaid(record.id)}
            className="flex items-center gap-1.5 bg-[#00a884] text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md hover:bg-[#00c99a] active:scale-95 transition-all"
          >
            <CheckCircle2 size={13} />
            {t.markPaid}
          </button>
        ) : (
          <div className="flex items-center gap-1.5 text-[#00a884] font-bold text-[10px] uppercase tracking-widest italic bg-[#00a884]/10 px-3 py-1 rounded-full border border-[#00a884]/20">
            <CheckCircle2 size={13} />
            {t.cleared}
          </div>
        )}
      </div>

      <span className="absolute bottom-1 right-2.5 text-[8px] text-[#8696a0] font-mono opacity-40">
        {format(new Date(), 'HH:mm')}
      </span>
    </motion.div>
  );
}

function AddRecordModal({ 
  onClose, 
  onAdd, 
  activeTab, 
  t,
  isUrdu
}: { 
  onClose: () => void, 
  onAdd: (r: any) => void, 
  activeTab: string, 
  t: any,
  isUrdu: boolean
}) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    desc: '',
    amount: '',
    dueDate: format(addDays(new Date(), 7), 'yyyy-MM-dd'),
    date: format(new Date(), 'yyyy-MM-dd')
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.amount) return;

    onAdd({
      type: activeTab === 'customers' ? 'customer' : 'supplier',
      customerName: activeTab === 'customers' ? formData.name : undefined,
      supplierName: activeTab === 'suppliers' ? formData.name : undefined,
      phoneNumber: formData.phone,
      description: formData.desc,
      amount: Number(formData.amount),
      date: formData.date,
      dueDate: formData.dueDate
    });
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
      <motion.div 
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="bg-[#202c33] w-full max-w-md rounded-t-3xl sm:rounded-3xl pb-10 sm:pb-6 overflow-hidden border-t sm:border border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]"
      >
        <div className="bg-[#2a3942] p-5 text-[#e9edef] flex justify-between items-center border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#00a884]/20 rounded-xl flex items-center justify-center text-[#00a884]">
              {activeTab === 'customers' ? <Users size={20} /> : <Store size={20} />}
            </div>
            <div>
              <h2 className="font-bold text-base leading-tight">{t.addRecord}</h2>
              <p className="text-[10px] text-[#8696a0] font-bold uppercase tracking-wider">{activeTab === 'customers' ? t.customers : t.suppliers}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={20} /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-5">
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-2 px-1">{activeTab === 'customers' ? t.customerName : t.supplierName}</label>
              <input 
                autoFocus
                required
                className="w-full bg-[#2a3942] border border-white/5 rounded-2xl px-5 py-4 text-[#e9edef] text-lg outline-none focus:border-[#00a884] focus:ring-2 focus:ring-[#00a884]/20 transition-all placeholder:text-[#8696a0]/30"
                placeholder="..."
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            {activeTab === 'customers' && (
              <div>
                <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-2 px-1">{t.phoneNumber}</label>
                <input 
                  type="tel"
                  className="w-full bg-[#2a3942] border border-white/5 rounded-2xl px-5 py-4 text-[#e9edef] text-lg outline-none focus:border-[#00a884] transition-all placeholder:text-[#8696a0]/30"
                  placeholder="03xx xxxxxxx"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
            )}

            <div>
              <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-2 px-1">{t.medicineDesc}</label>
              <textarea 
                className="w-full bg-[#2a3942] border border-white/5 rounded-2xl px-5 py-3 text-[#e9edef] outline-none focus:border-[#00a884] transition-all placeholder:text-[#8696a0]/30 resize-none"
                rows={2}
                placeholder="..."
                value={formData.desc}
                onChange={e => setFormData({ ...formData, desc: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-2 px-1">{t.amount}</label>
                <input 
                  type="number"
                  required
                  className="w-full bg-[#2a3942] border border-white/5 rounded-2xl px-5 py-4 text-[#e9edef] text-lg outline-none focus:border-[#00a884] transition-all font-bold"
                  placeholder="0.00"
                  value={formData.amount}
                  onChange={e => setFormData({ ...formData, amount: e.target.value })}
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-2 px-1">{activeTab === 'customers' ? t.expectedDate : t.dueDate}</label>
                <input 
                  type="date"
                  required
                  className="w-full bg-[#2a3942] border border-white/5 rounded-2xl px-5 py-4 text-[#e9edef] text-sm outline-none focus:border-[#00a884] transition-all [color-scheme:dark]"
                  value={formData.dueDate}
                  onChange={e => setFormData({ ...formData, dueDate: e.target.value })}
                />
              </div>
            </div>
          </div>

          <button className="w-full bg-[#00a884] text-white py-4.5 rounded-2xl font-bold text-lg shadow-[0_8px_20px_rgba(0,168,132,0.3)] hover:bg-[#00c99a] active:scale-[0.98] transition-all flex items-center justify-center gap-3 mt-6">
            {t.addRecord}
            <ArrowRight size={22} className={cn(isUrdu && "rotate-180")} />
          </button>
        </form>
      </motion.div>
    </div>
  );
}

function SettingsPanel({ settings, setSettings, t, records, setRecords }: { settings: AppSettings, setSettings: any, t: any, records: AppRecord[], setRecords: any }) {
  const isUrdu = settings.language === 'ur';

  const clearData = () => {
    if (confirm(t.clearAllData + '?')) {
      setRecords([]);
      alert(isUrdu ? 'ترمیم مکمل!' : 'Done!');
    }
  };

  const exportToCSV = () => {
    if (records.length === 0) {
      alert(t.noRecords);
      return;
    }

    const headers = ["ID", "Type", "Name", "Phone", "Description", "Amount", "Date", "Due Date", "Status"];
    const csvRows = records.map(r => [
      r.id,
      r.type,
      r.type === 'customer' ? r.customerName : r.supplierName,
      r.type === 'customer' ? r.phoneNumber : '-',
      r.description.replace(/,/g, ' '),
      r.amount,
      r.date,
      r.dueDate,
      r.status
    ].join(','));

    const csvContent = [headers.join(','), ...csvRows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `asquafmedical_report_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const supplierSummary = useMemo(() => {
    return records
      .filter(r => r.type === 'supplier' && r.status !== 'paid')
      .map(r => {
        const diff = differenceInDays(parseISO(r.dueDate), new Date());
        return { ...r, daysLeft: diff };
      })
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [records]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="space-y-6 pb-12"
    >
      {/* Summary Card */}
      {supplierSummary.length > 0 && (
        <div className="bg-[#202c33] rounded-3xl shadow-xl border border-white/5 overflow-hidden">
          <div className="bg-[#005c4b] p-4 text-[#e9edef] flex items-center gap-3">
            <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
              <Bell size={18} className="text-[#00a884]" />
            </div>
            <h3 className="font-bold text-sm tracking-wide">{t.summaryTitle}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className={cn("w-full text-sm", isUrdu && "text-right")}>
              <thead>
                <tr className="bg-[#111b21] border-b border-white/5">
                  <th className="px-5 py-3 font-bold text-[#8696a0] text-[10px] uppercase tracking-widest">{t.supplierName}</th>
                  <th className="px-5 py-3 font-bold text-[#8696a0] text-[10px] uppercase tracking-widest">{t.amount}</th>
                  <th className="px-5 py-3 font-bold text-[#8696a0] text-[10px] uppercase tracking-widest">{t.dueIn}</th>
                </tr>
              </thead>
              <tbody>
                {supplierSummary.map((s: any) => (
                  <tr key={s.id} className="border-b border-white/5 last:border-0 hover:bg-white/[0.02] transition-colors">
                    <td className="px-5 py-4 font-medium text-[#e9edef]">{s.supplierName}</td>
                    <td className="px-5 py-4 text-[#00a884] font-bold text-base">Rs. {s.amount.toLocaleString()}</td>
                    <td className="px-5 py-4">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider inline-block border",
                        s.daysLeft <= 0 
                          ? "bg-red-500/10 text-red-500 border-red-500/20" 
                          : (s.daysLeft <= 2 ? "bg-yellow-500/10 text-yellow-500 border-yellow-500/20" : "bg-[#00a884]/10 text-[#00a884] border-[#00a884]/20")
                      )}>
                        {s.daysLeft <= 0 ? t.overdue : `${s.daysLeft} ${t.daysLeft}`}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Settings Form */}
      <div className="bg-[#202c33] rounded-3xl shadow-xl border border-white/5 p-6 space-y-7">
        <div className="space-y-6">
          <div>
            <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-3 px-1">{t.pharmacyNameLabel}</label>
            <div className="relative">
              <Store className="absolute left-4 top-1/2 -translate-y-1/2 text-[#8696a0]/50" size={18} />
              <input 
                className="w-full bg-[#2a3942] border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-[#e9edef] outline-none focus:border-[#00a884] transition-all"
                value={settings.pharmacyName}
                onChange={e => setSettings({ ...settings, pharmacyName: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-3 px-1">{t.reminderTimeLabel}</label>
            <div className="relative">
              <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-[#8696a0]/50" size={18} />
              <input 
                type="time"
                className="w-full bg-[#2a3942] border border-white/5 rounded-2xl pl-12 pr-4 py-4 text-[#e9edef] outline-none focus:border-[#00a884] transition-all [color-scheme:dark]"
                value={settings.reminderTime}
                onChange={e => setSettings({ ...settings, reminderTime: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-[#8696a0] uppercase tracking-widest block mb-3 px-1">{t.languageLabel}</label>
            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => setSettings({ ...settings, language: 'en' })}
                className={cn(
                  "py-4 rounded-2xl border-2 transition-all font-bold text-sm uppercase tracking-widest",
                  settings.language === 'en' ? "border-[#00a884] bg-[#00a884]/10 text-[#00a884]" : "border-white/5 text-[#8696a0] bg-[#2a3942]"
                )}
              >
                English
              </button>
              <button 
                onClick={() => setSettings({ ...settings, language: 'ur' })}
                className={cn(
                  "py-4 rounded-2xl border-2 transition-all font-bold text-sm",
                  settings.language === 'ur' ? "border-[#00a884] bg-[#00a884]/10 text-[#00a884]" : "border-white/5 text-[#8696a0] bg-[#2a3942]"
                )}
              >
                اردو
              </button>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-white/5 space-y-3">
          <button 
            onClick={exportToCSV}
            className="w-full flex items-center justify-center gap-3 text-[#00a884] font-bold py-4 bg-[#00a884]/10 hover:bg-[#00a884]/20 rounded-2xl transition-all border border-[#00a884]/20 text-sm uppercase tracking-widest"
          >
            <ArrowRight size={18} className={cn("rotate-90", isUrdu && "rotate-[270deg]")} />
            {t.exportData}
          </button>
          <button 
            onClick={clearData}
            className="w-full flex items-center justify-center gap-3 text-red-500/80 font-bold py-4 hover:bg-red-500/10 rounded-2xl transition-all border border-transparent hover:border-red-500/20 text-sm uppercase tracking-widest"
          >
            <Trash2 size={18} />
            {t.clearAllData}
          </button>
        </div>
      </div>

      <div className="text-center text-[#8696a0]/40 text-[9px] uppercase tracking-[0.2em] font-bold pb-4">
        <p>AsquafMedical v2.0</p>
        <div className="flex items-center justify-center gap-1.5 mt-2">
          <span className="w-1 h-1 bg-[#00a884]/40 rounded-full" />
          <p>Secure Offline Storage</p>
          <span className="w-1 h-1 bg-[#00a884]/40 rounded-full" />
        </div>
      </div>
    </motion.div>
  );
}
